// Default and Named Export
class Nokia {
  VolumnUp() {
    console.log("High Volumn");
  }
}

function show() {
  console.log("Hello Module");
}

export default Nokia;
export { show };
