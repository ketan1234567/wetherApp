// Named Export Class
export class Nokia {
  VolumnUp() {
    console.log("High Volumn");
  }
}

/*
class Nokia {
  VolumnUp() {
    console.log("High Volumn");
  }
}
export { Nokia };
*/
