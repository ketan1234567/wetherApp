const aboutController = (req, res) => {
 res.render('about')
}

export { aboutController }