const studentController = (req, res) => {
 res.render('student')
}

export { studentController }