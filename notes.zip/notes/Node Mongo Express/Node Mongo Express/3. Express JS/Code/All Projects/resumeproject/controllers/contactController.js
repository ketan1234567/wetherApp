const contactController = (req, res) => {
 res.render('contact', { 'title': 'Contact' })
}

export { contactController }