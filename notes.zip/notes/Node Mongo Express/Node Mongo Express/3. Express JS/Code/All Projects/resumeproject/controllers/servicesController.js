const servicesController = (req, res) => {
 res.render('services', { 'title': 'Services' })
}

export { servicesController }