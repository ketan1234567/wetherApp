var underConstruction = (req, res, next) => {
 res.render('siteuc')
}

export default underConstruction