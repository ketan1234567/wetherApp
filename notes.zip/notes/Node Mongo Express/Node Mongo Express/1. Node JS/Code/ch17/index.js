// Import & Export Module - Common JS
const name = require('./student.js');
console.log(name);


// const { nm, marks } = require('./student.js');
// console.log(nm);
// marks(10, 20);