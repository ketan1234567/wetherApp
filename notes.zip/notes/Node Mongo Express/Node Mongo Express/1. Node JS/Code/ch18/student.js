// Import & Export Module - ES6

const nm = "Sonam";

const marks = (math, sci) => {
 console.log(math + sci);
}

export default nm;
// export { nm, marks };
